
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
if(menuToggle){menuToggle.addEventListener('click',()=>navLinks.classList.toggle('open'));}

const toast = (message) => {
  const t = document.querySelector('.toast');
  if(!t) return;
  t.textContent = message;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2200);
};

const menu = [
  {id:'oxtails', name:'Braised Oxtails', price:24, desc:'Slow-cooked, tender and richly seasoned.', img:'assets/oxtail-meal.jpg'},
  {id:'porkchops', name:'Smothered Pork Chops', price:18, desc:'Savory gravy, onions and homestyle seasoning.', img:'assets/smothered-meal-framed.jpg'},
  {id:'meatloaf', name:'Classic Meatloaf Plate', price:17, desc:'San’s hearty meatloaf with traditional sides.', img:'assets/meatloaf-plate.jpg'},
  {id:'salisbury', name:'Salisbury Steak', price:18, desc:'Seasoned beef patties with onion gravy.', img:'assets/meatloaf-plate-framed.jpg'},
  {id:'friedfish', name:'Southern Fried Fish', price:19, desc:'Crisp cornmeal coating with pickles and peppers.', img:'assets/fried-fish.jpg'},
  {id:'gumbo', name:'Seafood Gumbo', price:20, desc:'Deep Louisiana flavor with seafood and sausage.', img:'assets/hero-poster.jpg'},
  {id:'cornbread', name:'Butter Cornbread', price:4, desc:'Golden, sweet and served with melted butter.', img:'assets/butter-cornbread.jpg'},
  {id:'sides', name:'Two Homestyle Sides', price:7, desc:'Choose greens, mac and cheese, beans or corn.', img:'assets/smothered-meal-framed.jpg'}
];

let cart = JSON.parse(localStorage.getItem('sans903cart') || '{}');

function money(n){return `$${n.toFixed(2)}`;}
function save(){localStorage.setItem('sans903cart', JSON.stringify(cart));}

function renderMenu(){
  const target = document.querySelector('#menu-list');
  if(!target) return;
  target.innerHTML = menu.map(item=>`
    <article class="menu-item">
      <img src="${item.img}" alt="${item.name}">
      <div>
        <h3>${item.name}</h3>
        <p>${item.desc}</p>
        <div class="row">
          <strong>${money(item.price)}</strong>
          <button class="btn btn-secondary add-btn" data-id="${item.id}">Add</button>
        </div>
      </div>
    </article>`).join('');
  target.querySelectorAll('.add-btn').forEach(btn=>btn.addEventListener('click',()=>{
    cart[btn.dataset.id]=(cart[btn.dataset.id]||0)+1; save(); renderCart(); toast('Added to your order');
  }));
}

function renderCart(){
  const box = document.querySelector('#cart-items');
  const totalEl = document.querySelector('#cart-total');
  if(!box || !totalEl) return;
  const rows = Object.entries(cart).filter(([,q])=>q>0);
  if(!rows.length){box.innerHTML='<p class="small">Your cart is empty. Add a few favorites from the menu.</p>'; totalEl.textContent='$0.00'; return;}
  box.innerHTML = rows.map(([id,q])=>{
    const item=menu.find(x=>x.id===id);
    return `<div class="cart-item">
      <div><strong>${item.name}</strong><br><span class="small">${money(item.price*q)}</span></div>
      <div class="qty">
        <button data-action="minus" data-id="${id}">−</button><strong>${q}</strong><button data-action="plus" data-id="${id}">+</button>
      </div>
    </div>`;
  }).join('');
  const total=rows.reduce((s,[id,q])=>s+menu.find(x=>x.id===id).price*q,0);
  totalEl.textContent=money(total);
  box.querySelectorAll('button').forEach(btn=>btn.addEventListener('click',()=>{
    const id=btn.dataset.id;
    cart[id]=(cart[id]||0)+(btn.dataset.action==='plus'?1:-1);
    if(cart[id]<=0) delete cart[id];
    save();renderCart();
  }));
}

function orderText(){
  const rows=Object.entries(cart).filter(([,q])=>q>0);
  const name=document.querySelector('#customer-name')?.value.trim();
  const phone=document.querySelector('#customer-phone')?.value.trim();
  const fulfillment=document.querySelector('#fulfillment')?.value;
  const date=document.querySelector('#order-date')?.value;
  const notes=document.querySelector('#notes')?.value.trim();
  if(!rows.length){toast('Please add at least one menu item');return null;}
  if(!name || !phone){toast('Please enter your name and phone number');return null;}
  const lines=rows.map(([id,q])=>{
    const item=menu.find(x=>x.id===id);
    return `${q} x ${item.name} - ${money(item.price*q)}`;
  });
  const total=rows.reduce((s,[id,q])=>s+menu.find(x=>x.id===id).price*q,0);
  return `New Sans the 903 Order\n\nCustomer: ${name}\nPhone: ${phone}\nFulfillment: ${fulfillment}\nRequested date/time: ${date || 'Please confirm'}\n\n${lines.join('\n')}\n\nEstimated total: ${money(total)}\nNotes: ${notes || 'None'}\n\nPlease confirm availability and final total.`;
}

document.querySelector('#text-order')?.addEventListener('click',()=>{
  const body=orderText(); if(!body) return;
  window.location.href=`sms:18179944922?&body=${encodeURIComponent(body)}`;
});
document.querySelector('#copy-order')?.addEventListener('click',async()=>{
  const body=orderText(); if(!body) return;
  try{await navigator.clipboard.writeText(body);toast('Order summary copied');}
  catch{toast('Unable to copy automatically');}
});
document.querySelector('#clear-cart')?.addEventListener('click',()=>{cart={};save();renderCart();toast('Cart cleared');});

renderMenu();renderCart();
